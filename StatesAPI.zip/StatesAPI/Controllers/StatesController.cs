using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StatesAPI.DTO;
using StatesAPI.Models;

namespace StatesAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatesController:ControllerBase
    {
        private readonly StatesContext _context;

        public StatesController(StatesContext context)
        {
           _context = context;
        }


        [HttpGet] 
        public async Task<IActionResult> GetStates()
        {
            var states = await _context.States.Select(s => StateToDTO(s)).ToListAsync();

            return Ok(states);
        }

        [Authorize]
        [HttpGet("{id}")]
       
        public async Task<IActionResult> GetStateById(int? id)
        {
           if(id == null)
           {
             return NotFound();
           }

            var s =  await _context
                                .States
                                .Where(i=> i.StateId == id)
                                .Select(s => StateToDTO(s))
                                .FirstOrDefaultAsync();

            if (s== null)
            {
                return NotFound();
            }

            return Ok(s);


        }

        [HttpPost]
        public async Task<IActionResult> CreateState(State entitiy)
        {
            _context.States.Add(entitiy);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetStateById), new { id = entitiy.StateId }, entitiy);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateState(int id, State entitiy)
        {
            if(id != entitiy.StateId)
            {
                return BadRequest();
            }

            var state = await _context.States.FirstOrDefaultAsync(i => i.StateId == id);

            if(state == null)
            {
                return NotFound();
            }

            state.StateName = entitiy.StateName;
            state.Price = entitiy.Price;
            state.isActive = entitiy.isActive;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch(Exception)
            {
                return NotFound();
            }

            return NoContent();

        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteState(int? id)
        {
            if(id == null)
            {
                return NotFound();
            }

            var state = await  _context.States.FirstOrDefaultAsync(i=> i.StateId == id);

            if(state == null)
            {
                return NotFound();
            }

            _context.States.Remove(state);
            
            try
            {
                await _context.SaveChangesAsync();
            }
            catch(Exception)
            {
                return NotFound();
            }

            return NoContent();
        }


        private static StateDTO StateToDTO(State s)
        {
            var entitiy = new StateDTO();
            if(s != null)
            {
                entitiy.StateId = s.StateId;
                entitiy.StateName = s.StateName;
                entitiy.Price = s.Price;
            }
            return entitiy;
            
        }



    }
}