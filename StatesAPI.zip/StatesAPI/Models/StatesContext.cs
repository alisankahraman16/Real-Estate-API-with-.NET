using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using StatesAPI.Controllers;

namespace StatesAPI.Models
{
    public class StatesContext:IdentityDbContext<AppUser, AppRole, int>
    {
        public StatesContext(DbContextOptions<StatesContext> options): base(options)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<State>().HasData(new State() {StateId = 1, StateName= "Daire 1", Price = 6000000,isActive= true});
        modelBuilder.Entity<State>().HasData(new State() {StateId = 2, StateName= "Daire 2", Price = 7000000,isActive= true});
        modelBuilder.Entity<State>().HasData(new State() {StateId = 3, StateName= "Daire 3", Price = 8000000,isActive= false});
        modelBuilder.Entity<State>().HasData(new State() {StateId = 4, StateName= "Daire 4", Price = 9000000,isActive= true});
        modelBuilder.Entity<State>().HasData(new State() {StateId = 5, StateName= "Daire 5", Price = 10000000,isActive= true});
        }
        public DbSet<State> States { get; set; }
    }
}